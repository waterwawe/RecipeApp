package com.example.recipeapp.network

interface RecipeService {

}