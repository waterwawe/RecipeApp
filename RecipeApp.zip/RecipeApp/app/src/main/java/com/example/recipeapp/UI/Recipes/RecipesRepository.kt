package com.example.recipeapp.UI.Recipes

import android.util.Log
import androidx.annotation.WorkerThread
import com.example.recipeapp.Network.RecipeService
import com.example.recipeapp.Persistance.RecipeDao
import com.example.recipeapp.model.Recipe
import com.skydoves.sandwich.onFailure
import com.skydoves.sandwich.suspendOnSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import javax.inject.Inject

class RecipesRepository @Inject constructor(
    private val recipeService: RecipeService,
    private val recipeDao: RecipeDao
){
    @WorkerThread
    fun loadRecipes(
        onStart: () -> Unit,
        onCompletion: () -> Unit,
        onError: (String) -> Unit,
        queryString: String
    ) = flow {
        var queryMap = HashMap<String,String>()
        queryMap.put("q",queryString)
        recipeService.searchRecipes(queryMap).suspendOnSuccess {
            emit(data.hits)
            Log.i("Tab changed","asd")
        }.onFailure { onError(this) }
    }.onStart { onStart() }.onCompletion { onCompletion() }.flowOn(Dispatchers.IO)

    @WorkerThread
    fun loadFavouriteRecipes(
        onStart: () -> Unit,
        onCompletion: () -> Unit,
    ) = flow {
        val recipes: List<Recipe> = recipeDao.getRecipeList()
        emit(recipes)
    }.onStart { onStart() }.onCompletion { onCompletion() }.flowOn(Dispatchers.IO)
}