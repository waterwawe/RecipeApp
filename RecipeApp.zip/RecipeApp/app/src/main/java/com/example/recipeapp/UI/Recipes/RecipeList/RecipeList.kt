package com.example.recipeapp.UI.Recipes.RecipeList


import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.recipeapp.UI.Recipes.RecipeFragment.RecipeCard
import com.example.recipeapp.model.Recipe
import com.google.accompanist.insets.statusBarsPadding

@Composable
fun RecipeList(
    modifier: Modifier = Modifier,
    recipes: List<Recipe>
){
    LazyColumn {
        items(recipes) { recipe ->
            Card(
                modifier = Modifier.padding(4.dp),
                backgroundColor = Color.LightGray
            ){
                RecipeCard(modifier,recipe)
            }
        }
    }
}