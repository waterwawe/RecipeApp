package com.example.recipeapp.UI.Recipes

import javax.inject.Inject

class RecipesRepository @Inject constructor(
    //private val recipeService: RecipeService
){
}