package com.example.recipeapp.Persistance

import androidx.room.Dao

@Dao
interface RecipeDao {
}